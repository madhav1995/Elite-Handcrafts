<html>
<head>
	<title></title>
	 <link rel="stylesheet" href="style.css" />
</head>
<body>
	<div class="signup">
           <h1>SIGNUP</h1>
           <form action="registration.php" method="post">
           <input type="text" name="Uid" placeholder="username"><br><br>
           <input type="text" name="mail" placeholder="E-mail"><br><br>
           <input type="password" name="Pwd" placeholder="password"><br><br>
           <input type="password" name="pwd-repeat" placeholder="Re-enter password"><br><br>
           <button type="submit" name="signup-submit" value="signup">SIGNUP</button><br><br>
           <h4>Already have an Account? <a href="index.html">LOGIN</a> here</h4>

           </form>
       </div>
   

	</body>
  </html>