<html>
<head>
	<title></title>
	 <link rel="stylesheet" href="style.css" />
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	
<footer class="footer">
      <h2>Elite Handcrafts</h2>
      <p>© 2019 Elite handcrafts. All Rights Reserved</p>
      <a href="https://www.facebook.com/EliteHandcrafts02/" class="fa fa-facebook"></a>
      <a href="https://www.instagram.com/elitehandcrafts/?hl=en" class="fa fa-instagram"></a>
    </footer>
  </body>
</html>
