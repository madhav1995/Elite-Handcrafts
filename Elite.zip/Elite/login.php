<? php
if (isset($_POST['login-submit'])) {

	require 'db.php';

	$mailuid = $_POST['mailuid'];
	$password = $_POST['pwd'];

	if (empty($mailuid) || empty($password)) {
		header("location: index.php?error=sqlerror");
		exit();
	}

}
else {
	header("location ");
	exit();

}
?>