<?php
 require "header.php";
  ?>
  

    <main>
           <?php
           require "index.php";
           ?>
    </main>







<?php
 require "footer.php";
  ?>