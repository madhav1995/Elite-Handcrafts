<html>
<head>
	<title></title>
	 <link rel="stylesheet" href="style.css" />
</head>
<body>
	<div class="navbar">
      <a href="index.html">Home</a>
      <a href="himalayan_salt.html">Offers</a>
      <div class="dropdown">
        <button class="dropbtn"> Products
        </button>
        <div class="dropdown-content">
            <a href="himalayan_salt.html">Himalayan Salt</a>
            <a href="bedroom.html">Bedroom & Living</a> 
            <a href="outdoor.html">Outdoor</a>
            <a href="others.html">Others</a>
        </div>
      </div> 
      <a href="locations.html">Locations</a>
      <a href="contact.html">Contact Us</a>
  </div>

	</body>
  </html>